﻿SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS  `activity`;
CREATE TABLE `activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '学生姓名',
  `parent` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '家长姓名',
  `phone` varchar(24) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '手机',
  `email` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `project` varchar(24) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '科目，或大班名字',
  `grade` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '年级',
  `type` tinyint(4) NOT NULL COMMENT '活动类型，从１开始，每期活动指定',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `memo` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '注释，用于跟进记录等',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态，0报名，1确认完成，２跟进中，３放弃',
  `ip` char(20) NOT NULL,
  `referer` varchar(200) NOT NULL,
  `username` varchar(24) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '关联的用户名，用于看活动效果',
  PRIMARY KEY (`id`),
  KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC COMMENT='活动记录表';

DROP TABLE IF EXISTS  `admin_action_record`;
CREATE TABLE `admin_action_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` char(12) NOT NULL COMMENT '管理员ip',
  `admin` char(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '管理员用户名',
  `target` char(40) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '被操作对象，可以没有，默认为u_用户名',
  `action` varchar(32) NOT NULL COMMENT '操作',
  `url` varchar(1024) NOT NULL COMMENT '操作的url',
  `info` varchar(1024) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '操作记录',
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=570 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC COMMENT='管理员操作记录';

DROP TABLE IF EXISTS  `bank_card`;
CREATE TABLE `bank_card` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) unsigned NOT NULL COMMENT '用户ID',
  `bank_name` varchar(64) NOT NULL COMMENT '银行名称',
  `bank_facepic` varchar(256) NOT NULL COMMENT '银行logo',
  `card` varchar(32) NOT NULL COMMENT '卡号',
  `name` varchar(32) NOT NULL COMMENT '户名',
  `created_at` int(11) unsigned NOT NULL DEFAULT '0',
  `updated_at` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `userid_card` (`userid`,`card`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `banners`;
CREATE TABLE `banners` (
  `bid` int(11) NOT NULL AUTO_INCREMENT,
  `pic` varchar(1024) NOT NULL,
  `text` varchar(512) NOT NULL,
  `type` tinyint(3) unsigned NOT NULL COMMENT '1:product,2:collection,3:live',
  `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `url` varchar(1024) NOT NULL,
  PRIMARY KEY (`bid`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS  `brand_category`;
CREATE TABLE `brand_category` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `brand_id` int(11) unsigned NOT NULL DEFAULT '0',
  `category_id` int(11) unsigned NOT NULL DEFAULT '0',
  `weight` decimal(4,1) unsigned NOT NULL DEFAULT '0.0' COMMENT '质量',
  `tax_rate` decimal(4,3) unsigned NOT NULL DEFAULT '0.000' COMMENT '税率',
  `volume` decimal(4,3) unsigned NOT NULL DEFAULT '0.000' COMMENT '体积',
  `brand_name` char(32) NOT NULL,
  `category_name` char(32) NOT NULL,
  `created_at` int(11) unsigned DEFAULT NULL,
  `updated_at` int(11) unsigned DEFAULT NULL,
  `status` tinyint(4) unsigned DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `brand_icae`;
CREATE TABLE `brand_icae` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `english_name` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL,
  `chinese_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=363 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `category`;
CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weight` decimal(3,1) DEFAULT '0.0',
  `tax_rate` decimal(4,3) DEFAULT '0.119',
  `name` varchar(256) NOT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `order` smallint(4) unsigned DEFAULT '100',
  `is_show` tinyint(1) unsigned DEFAULT '0',
  `description` varchar(4096) NOT NULL,
  `chinese_name` varchar(64) DEFAULT NULL,
  `cover_image` varchar(2048) NOT NULL,
  `level` tinyint(4) unsigned DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1007 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS  `category_icae`;
CREATE TABLE `category_icae` (
  `icae_id` int(11) NOT NULL AUTO_INCREMENT,
  `english_name` varchar(50) CHARACTER SET utf8mb4 NOT NULL,
  `chinese_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`icae_id`)
) ENGINE=InnoDB AUTO_INCREMENT=134 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `collection`;
CREATE TABLE `collection` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `author` int(11) NOT NULL COMMENT 'owner',
  `title` varchar(2048) COLLATE utf8_unicode_ci NOT NULL COMMENT 'title',
  `description` text COLLATE utf8_unicode_ci,
  `background_image` varchar(2048) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cover_image` varchar(2048) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_update` int(11) unsigned DEFAULT NULL,
  `status` smallint(6) NOT NULL DEFAULT '0',
  `status_plus` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '审核状态 20 申请编辑',
  `view_count` int(11) NOT NULL,
  `publish_time` datetime NOT NULL,
  `type` tinyint(4) unsigned NOT NULL DEFAULT '2',
  `is_recommended` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `is_pushed` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `subhead` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content_image` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  `recommond_image` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=201 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS  `collection3_item`;
CREATE TABLE `collection3_item` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `collection_id` int(11) unsigned NOT NULL,
  `order` tinyint(4) unsigned NOT NULL DEFAULT '1',
  `img1` varchar(256) DEFAULT NULL,
  `img2` varchar(256) DEFAULT NULL,
  `text1` text,
  `text2` text,
  `products` varchar(64) DEFAULT NULL,
  `create_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `collection_item`;
CREATE TABLE `collection_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `collection_id` int(11) NOT NULL,
  `position` smallint(4) unsigned NOT NULL DEFAULT '0',
  `content` varchar(4096) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` tinyint(2) NOT NULL DEFAULT '1',
  `last_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `product_id` int(11) NOT NULL,
  `text` varchar(4096) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `collection_id` (`collection_id`) USING BTREE,
  KEY `product_id` (`product_id`) USING BTREE,
  KEY `position` (`position`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=8175 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS  `color`;
CREATE TABLE `color` (
  `color_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(1024) COLLATE utf8_unicode_ci NOT NULL,
  `author` int(11) DEFAULT NULL,
  `description` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`color_id`),
  KEY `name` (`name`(255))
) ENGINE=InnoDB AUTO_INCREMENT=303230 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS  `commond`;
CREATE TABLE `commond` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(11) unsigned NOT NULL,
  `cover_url` varchar(255) DEFAULT NULL,
  `create_at` int(11) unsigned DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=825 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `country`;
CREATE TABLE `country` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(24) NOT NULL,
  `flag_url` varchar(256) DEFAULT NULL COMMENT '国旗',
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `coupon`;
CREATE TABLE `coupon` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `type` tinyint(4) unsigned NOT NULL DEFAULT '1',
  `value` int(11) unsigned NOT NULL DEFAULT '0',
  `limit` int(11) unsigned NOT NULL DEFAULT '0',
  `description` varchar(512) NOT NULL,
  `get_at` int(11) unsigned NOT NULL,
  `get_end` int(11) unsigned NOT NULL,
  `use_at` int(11) unsigned NOT NULL,
  `use_end` int(11) unsigned NOT NULL,
  `created_at` int(11) unsigned NOT NULL,
  `updated_at` int(11) unsigned NOT NULL,
  `created_sum` int(11) NOT NULL DEFAULT '0',
  `geted_sum` int(11) unsigned NOT NULL DEFAULT '0',
  `used_sum` int(11) unsigned NOT NULL DEFAULT '0',
  `store` int(11) unsigned NOT NULL DEFAULT '0',
  `category` int(11) unsigned NOT NULL DEFAULT '0',
  `is_exclusive` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `get_limit` tinyint(4) unsigned NOT NULL DEFAULT '1',
  `time_limit` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `mobile_limit` text,
  `reg_at` int(11) NOT NULL,
  `reg_end` int(11) NOT NULL,
  `reg_min` tinyint(4) unsigned NOT NULL DEFAULT '3',
  `get_cid` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `repeat` tinyint(4) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `deal`;
CREATE TABLE `deal` (
  `order_id` char(64) COLLATE utf8_unicode_ci NOT NULL COMMENT '订单编号',
  `pid` char(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0' COMMENT '父订单ID',
  `status` int(4) NOT NULL DEFAULT '0' COMMENT 'define(''ORDER_STATUS_INIT'',0);\n\ndefine(''ORDER_STATUS_PRE_PAID'',10);\n\ndefine(''ORDER_STATUS_LAST_PAY_START'',20);\ndefine(''ORDER_STATUS_LAST_PAY_END'',21);\ndefine(''ORDER_STATUS_LAST_PAID'',24);\n\ndefine(''ORDER_STATUS_SHIP_START'',30);\ndefine(''ORDER_STATUS_SHIP_RECEIVED'',31);\ndefine(''ORDER_STATUS_END_SUCCEED'',40);\ndefine(''ORDER_STATUS_END_FAIL'',41);\n',
  `product_id` int(11) NOT NULL COMMENT 'product id\n',
  `product_price` decimal(10,2) DEFAULT NULL,
  `product_count` int(11) DEFAULT NULL COMMENT '产品数量\n',
  `product_color` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'color值',
  `product_size` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'size值',
  `freight` decimal(10,0) DEFAULT NULL,
  `tax` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `last_pay_coupon_value` decimal(10,0) DEFAULT '0' COMMENT '优惠金额',
  `promotion_value` decimal(10,2) NOT NULL DEFAULT '0.00',
  `last_paid_money` decimal(10,2) DEFAULT '0.00' COMMENT '尾款实际付的钱\n',
  `last_payment` char(16) COLLATE utf8_unicode_ci NOT NULL COMMENT '支付方式（支付宝，微信..)',
  `last_paid_time` datetime DEFAULT NULL,
  `buyer_userid` int(11) NOT NULL,
  `last_pay_coupon_code` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `promotion_code` varchar(2048) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_paid_payinfo` char(64) COLLATE utf8_unicode_ci NOT NULL COMMENT 'payinfo id',
  `ship_info_id` int(11) DEFAULT NULL,
  `shipping_info` text COLLATE utf8_unicode_ci NOT NULL,
  `overseas` text COLLATE utf8_unicode_ci,
  `product_title` varchar(1024) COLLATE utf8_unicode_ci DEFAULT NULL,
  `product_cover_image` varchar(2048) COLLATE utf8_unicode_ci DEFAULT NULL,
  `memo` varchar(128) COLLATE utf8_unicode_ci NOT NULL COMMENT '买家留言',
  `remarks` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '客服备注',
  `order_sum` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '子订单个数',
  `create_time` datetime DEFAULT NULL,
  `last_update` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `seller_userid` int(11) DEFAULT NULL,
  `courier_company` varchar(96) COLLATE utf8_unicode_ci NOT NULL,
  `courier_number` varchar(96) COLLATE utf8_unicode_ci NOT NULL,
  `courier_send_time` datetime NOT NULL,
  `out_of_stock_note` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `freight_id` int(11) DEFAULT NULL,
  `type` tinyint(2) DEFAULT NULL,
  `product_presale_price` decimal(10,2) DEFAULT NULL,
  `pre_pay_coupon_code` char(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pre_pay_coupon_value` decimal(10,0) DEFAULT '0',
  `pre_paid_money` decimal(10,2) DEFAULT '0.00',
  `pre_paid_time` datetime DEFAULT NULL,
  `pre_paid_payinfo` char(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pre_payment` char(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_pay_money` decimal(10,2) DEFAULT '0.00',
  `last_pay_start_time` datetime DEFAULT NULL,
  `last_pay_end_time` datetime DEFAULT NULL,
  `courier_receive_time` datetime NOT NULL,
  `referer` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '推荐人Userid',
  `wx_prepay_id` varchar(64) COLLATE utf8_unicode_ci DEFAULT '0',
  PRIMARY KEY (`order_id`),
  KEY `username` (`buyer_userid`),
  KEY `status` (`status`),
  KEY `type` (`type`) USING BTREE,
  KEY `related_id` (`product_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS  `dealcart`;
CREATE TABLE `dealcart` (
  `cartid` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `product_id` int(11) NOT NULL COMMENT 'product id\n',
  `product_count` int(11) DEFAULT NULL COMMENT '产品数量\n',
  `product_color` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'color值',
  `product_size` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'size值',
  `color` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `size` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `cctimes` int(11) unsigned NOT NULL DEFAULT '0',
  `is_luxury` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `referer` int(11) unsigned DEFAULT '0' COMMENT '推荐人Userid',
  PRIMARY KEY (`cartid`)
) ENGINE=InnoDB AUTO_INCREMENT=8948 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS  `discount_tags`;
CREATE TABLE `discount_tags` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) CHARACTER SET utf8 NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS  `excel_user2cate`;
CREATE TABLE `excel_user2cate` (
  `COL1` varchar(28) NOT NULL DEFAULT '',
  `COL 2` varchar(67) DEFAULT NULL,
  `COL 3` varchar(19) DEFAULT NULL,
  `COL 4` varchar(19) DEFAULT NULL,
  `COL 5` varchar(19) DEFAULT NULL,
  `COL 6` varchar(15) DEFAULT NULL,
  `COL 7` varchar(18) DEFAULT NULL,
  `COL 8` varchar(31) DEFAULT NULL,
  `COL 9` varchar(15) DEFAULT NULL,
  `COL 10` varchar(15) DEFAULT NULL,
  `COL 11` varchar(8) DEFAULT NULL,
  `COL 12` varchar(7) DEFAULT NULL,
  `COL 13` varchar(7) DEFAULT NULL,
  `COL 14` varchar(5) DEFAULT NULL,
  `COL 15` varchar(7) DEFAULT NULL,
  `COL 16` varchar(8) DEFAULT NULL,
  `COL 17` varchar(7) DEFAULT NULL,
  `COL 18` varchar(7) DEFAULT NULL,
  `COL 19` varchar(22) DEFAULT NULL,
  `COL 20` varchar(26) DEFAULT NULL,
  `COL 21` varchar(23) DEFAULT NULL,
  `COL 22` varchar(24) DEFAULT NULL,
  `COL 23` varchar(21) DEFAULT NULL,
  `COL 24` varchar(32) DEFAULT NULL,
  `COL 25` varchar(19) DEFAULT NULL,
  `COL 26` varchar(19) DEFAULT NULL,
  `COL 27` varchar(16) DEFAULT NULL,
  `COL 28` varchar(13) DEFAULT NULL,
  `COL 29` varchar(8) DEFAULT NULL,
  PRIMARY KEY (`COL1`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

DROP TABLE IF EXISTS  `failed_jobs`;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28559 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS  `fd_session`;
CREATE TABLE `fd_session` (
  `session_id` char(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '加密session标识',
  `userid` int(11) DEFAULT NULL,
  `username` char(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '登录用户名（未登录为空）',
  `usertype` int(4) NOT NULL COMMENT '0:未知，2：学生，1：老师',
  `status` int(4) DEFAULT NULL COMMENT '0：未登录；1：登录',
  `sess_create_time` datetime DEFAULT NULL COMMENT 'session创建时间',
  `login_time` datetime DEFAULT NULL COMMENT '用户登录时间',
  `logout_time` datetime DEFAULT NULL COMMENT '用户退出时间',
  `last_activity` int(11) DEFAULT NULL COMMENT '最近活动时间',
  `activity_times` int(4) DEFAULT NULL COMMENT '访问次数',
  `pass_wrong_times` int(4) DEFAULT '0' COMMENT '密码错误次数',
  `view_tea_record` int(11) DEFAULT NULL COMMENT '浏览过的老师列表',
  `ip_address` varchar(45) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '第一次访问ip',
  `user_agent` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '用户终端信息',
  `user_data` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '额外信息',
  PRIMARY KEY (`session_id`),
  KEY `username` (`username`),
  KEY `sess_create_time` (`sess_create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='bp-session info table';

DROP TABLE IF EXISTS  `footmark`;
CREATE TABLE `footmark` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `product_id` int(11) unsigned NOT NULL,
  `browse_at` int(11) unsigned NOT NULL,
  `referer` int(11) unsigned DEFAULT '0' COMMENT '推荐人Userid',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `browse_at` (`browse_at`)
) ENGINE=InnoDB AUTO_INCREMENT=70387 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `history`;
CREATE TABLE `history` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) unsigned NOT NULL,
  `keywords` varchar(256) NOT NULL,
  `used_time` int(11) unsigned NOT NULL,
  `created_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=74260 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `jobs`;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_reserved_at_index` (`queue`(191),`reserved_at`)
) ENGINE=InnoDB AUTO_INCREMENT=209525 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS  `message`;
CREATE TABLE `message` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctype` tinyint(4) unsigned DEFAULT '0',
  `tid` int(11) DEFAULT NULL COMMENT 'zhuti',
  `type` tinyint(4) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `title` varchar(128) DEFAULT NULL,
  `content` varchar(1024) DEFAULT NULL,
  `create_at` int(11) unsigned NOT NULL,
  `available_end` int(11) unsigned DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `extra` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `available_end` (`available_end`),
  KEY `create_at` (`create_at`),
  KEY `tid` (`tid`)
) ENGINE=InnoDB AUTO_INCREMENT=3190963 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `migrations`;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS  `new_deal`;
CREATE TABLE `new_deal` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `deal` decimal(11,2) unsigned DEFAULT '0.00',
  `pay` decimal(11,2) unsigned DEFAULT '0.00',
  `timestamp` int(11) unsigned DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `timestamp` (`timestamp`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `new_register`;
CREATE TABLE `new_register` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `new` int(11) unsigned DEFAULT '0' COMMENT '新注册用户数',
  `active` int(11) unsigned DEFAULT '0' COMMENT '活跃用户数',
  `start` int(11) unsigned DEFAULT '0' COMMENT '启动次数',
  `timestamp` int(11) unsigned DEFAULT '0' COMMENT '时间戳',
  PRIMARY KEY (`id`),
  KEY `timestamp` (`timestamp`)
) ENGINE=InnoDB AUTO_INCREMENT=481 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `paper_pay`;
CREATE TABLE `paper_pay` (
  `pay_id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `session` char(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `data` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '交易数据',
  PRIMARY KEY (`pay_id`),
  KEY `paper_id` (`pid`,`username`,`session`),
  KEY `session` (`session`),
  KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC COMMENT='试卷购买记录';

DROP TABLE IF EXISTS  `pay_info`;
CREATE TABLE `pay_info` (
  `info_id` char(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `discount` decimal(10,2) NOT NULL,
  `payment_type` tinyint(4) NOT NULL,
  `subject` varchar(128) NOT NULL,
  `trade_no` varchar(64) NOT NULL,
  `buyer_email` varchar(128) NOT NULL,
  `gmt_create` datetime NOT NULL,
  `notify_type` varchar(128) NOT NULL,
  `quantity` smallint(5) unsigned NOT NULL,
  `out_trade_no` varchar(128) NOT NULL,
  `seller_id` varchar(128) NOT NULL,
  `notify_time` datetime NOT NULL,
  `body` varchar(1024) NOT NULL,
  `trade_status` varchar(32) NOT NULL,
  `is_total_fee_adjust` char(2) NOT NULL,
  `total_fee` decimal(10,2) NOT NULL,
  `gmt_payment` datetime NOT NULL,
  `seller_email` varchar(128) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `buyer_id` varchar(64) NOT NULL,
  `notify_id` varchar(64) NOT NULL,
  `use_coupon` char(2) NOT NULL,
  `sign_type` char(10) NOT NULL,
  `sign` varchar(1024) NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `valid` tinyint(4) NOT NULL DEFAULT '1',
  `remark` varchar(4000) NOT NULL COMMENT '备注信息',
  PRIMARY KEY (`info_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `pay_result_notify`;
CREATE TABLE `pay_result_notify` (
  `notify_id` int(11) NOT NULL AUTO_INCREMENT,
  `pay_type` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notify_time` datetime DEFAULT NULL,
  `notify` text COLLATE utf8_unicode_ci,
  `verify_result` int(11) NOT NULL DEFAULT '0' COMMENT '验证是否成功，1：成功，-1: before verifying, 其他：不成功',
  PRIMARY KEY (`notify_id`),
  KEY `pay_type` (`pay_type`,`notify_time`),
  KEY `verify_result` (`verify_result`)
) ENGINE=InnoDB AUTO_INCREMENT=964 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS  `product`;
CREATE TABLE `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(1024) COLLATE utf8_unicode_ci DEFAULT NULL,
  `price` decimal(10,0) DEFAULT '0',
  `category` int(11) DEFAULT '0' COMMENT '对应category id',
  `author` int(11) DEFAULT '0',
  `store` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '来源商城',
  `status` smallint(2) DEFAULT '0' COMMENT '0：draft\n1：published\n',
  `presale_price` decimal(10,0) DEFAULT '0',
  `last_price` decimal(10,0) unsigned DEFAULT '0',
  `description` text COLLATE utf8_unicode_ci,
  `create_time` datetime DEFAULT NULL,
  `save_time` datetime DEFAULT NULL,
  `rank` int(11) DEFAULT NULL COMMENT 'rank',
  `last_update` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `m_sku` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `cover_image` varchar(2048) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '首图',
  `tmp_img` text COLLATE utf8_unicode_ci NOT NULL,
  `m_url` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `discount` decimal(3,2) unsigned NOT NULL DEFAULT '1.00' COMMENT '折扣discount',
  `view_count` int(11) DEFAULT '0' COMMENT '浏览次数',
  `m_promotionalDeal` text COLLATE utf8_unicode_ci COMMENT 'json_source',
  `md_title` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'md5 title price',
  `property` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '属性',
  `inventory` int(11) DEFAULT '0' COMMENT '库存数量',
  `is_commond` tinyint(4) unsigned DEFAULT '0' COMMENT '推荐单品',
  `publish_time` datetime DEFAULT NULL,
  `sell_type` tinyint(2) DEFAULT '0',
  `presale_minimum` int(4) DEFAULT '0' COMMENT '最少起订量',
  `presale_maximum` int(11) DEFAULT '0',
  `presale_days` int(11) DEFAULT '0',
  `presale_end_time` int(11) NOT NULL DEFAULT '0',
  `production_days` int(11) DEFAULT '0',
  `status_plus` tinyint(4) NOT NULL DEFAULT '0',
  `lover_count` int(11) DEFAULT '0' COMMENT '喜欢人数',
  `sold_count` int(11) DEFAULT '0' COMMENT '喜欢数量',
  `presold_count` int(11) DEFAULT '0' COMMENT '预售已经付费人数',
  `promotion` smallint(4) DEFAULT '0' COMMENT '1:编辑推荐',
  `m_hasFavorite` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `m_preOwned` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `m_rental` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `position` smallint(4) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `position_at` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '排序时间',
  `including_mfee` int(11) unsigned DEFAULT '0' COMMENT '包含运费',
  `pdt_price` decimal(10,0) unsigned DEFAULT '0' COMMENT '纯商品价格',
  PRIMARY KEY (`id`),
  KEY `catgory` (`category`),
  KEY `author` (`author`),
  KEY `status` (`status`),
  KEY `IDX_M_SKU` (`m_sku`),
  KEY `price` (`price`),
  KEY `rank` (`rank`) USING BTREE,
  KEY `position` (`position`) USING BTREE,
  KEY `including_mfee` (`including_mfee`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1860820 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS  `product_album`;
CREATE TABLE `product_album` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `position` smallint(4) DEFAULT NULL,
  `content` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` tinyint(2) NOT NULL DEFAULT '1',
  `last_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `url` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '源网址',
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=519145497 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS  `product_color`;
CREATE TABLE `product_color` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `color_id` int(11) NOT NULL,
  `name` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pid` (`product_id`,`color_id`),
  KEY `pid_2` (`product_id`),
  KEY `tid` (`color_id`)
) ENGINE=InnoDB AUTO_INCREMENT=395358680 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS  `product_liker`;
CREATE TABLE `product_liker` (
  `product_id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `created_at` int(11) unsigned NOT NULL DEFAULT '0',
  `referer` int(11) unsigned DEFAULT '0' COMMENT '推荐人Userid',
  PRIMARY KEY (`product_id`,`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `product_size`;
CREATE TABLE `product_size` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `size_id` int(11) NOT NULL,
  `name` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pid` (`product_id`,`size_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1047459346 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS  `product_spider`;
CREATE TABLE `product_spider` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '用户名',
  `list_progress_id` int(11) DEFAULT '0' COMMENT '采集用户索引进程ID',
  `list_uptime` int(10) DEFAULT NULL COMMENT '抓取索引时间',
  `list_server_id` tinyint(1) DEFAULT '0',
  `info_progress_id` int(11) DEFAULT '0' COMMENT '采集用户信息进程ID',
  `info_uptime` int(10) DEFAULT NULL COMMENT '抓取信息时间',
  `info_server_id` tinyint(1) DEFAULT '0',
  `status` tinyint(1) DEFAULT '0' COMMENT '状态',
  `addtime` int(10) DEFAULT NULL COMMENT '添加时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`url`),
  KEY `info_progress_id` (`info_progress_id`),
  KEY `uptime` (`info_uptime`),
  KEY `index_time` (`list_uptime`),
  KEY `index_progress_id` (`list_progress_id`),
  KEY `list_server_id` (`list_server_id`),
  KEY `info_server_id` (`info_server_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `product_tags`;
CREATE TABLE `product_tags` (
  `pid` int(11) unsigned NOT NULL COMMENT '商品ID',
  `price_id` int(11) unsigned NOT NULL COMMENT '价格区间 标签ID',
  `category_id` int(11) unsigned NOT NULL COMMENT '分类 标签ID',
  `brand_id` int(11) unsigned NOT NULL COMMENT '品牌 标签ID',
  `discount_id` int(11) DEFAULT NULL COMMENT '折扣 标签ID',
  `cate3` int(11) unsigned DEFAULT '0' COMMENT '3级分类ID',
  PRIMARY KEY (`pid`),
  UNIQUE KEY `pid` (`pid`) USING BTREE,
  KEY `price` (`price_id`),
  KEY `category` (`category_id`),
  KEY `brand` (`brand_id`),
  KEY `cate3` (`cate3`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商品ID和价格区间、分类、品牌间的关系表， by fisher';

DROP TABLE IF EXISTS  `profiler`;
CREATE TABLE `profiler` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uri` varchar(256) NOT NULL,
  `class_method` varchar(256) NOT NULL,
  `total_et` int(11) NOT NULL,
  `controller_et` int(11) NOT NULL,
  `benchmark` varchar(4096) NOT NULL,
  `get` varchar(4096) NOT NULL,
  `post` varchar(4096) NOT NULL,
  `memu` int(11) NOT NULL,
  `mpu` int(11) NOT NULL,
  `queries` varchar(4096) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=319870 DEFAULT CHARSET=utf8 COMMENT='profiler';

DROP TABLE IF EXISTS  `proxy`;
CREATE TABLE `proxy` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip` varchar(15) NOT NULL,
  `port` int(11) unsigned NOT NULL,
  `times` int(11) unsigned NOT NULL DEFAULT '0',
  `network_delay` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(4) unsigned NOT NULL DEFAULT '1',
  `get_at` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `times` (`times`),
  KEY `get_at` (`get_at`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=719640 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `return_back`;
CREATE TABLE `return_back` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) unsigned NOT NULL,
  `type` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `order_id` char(64) DEFAULT NULL,
  `products` varchar(512) DEFAULT NULL,
  `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `reason` varchar(1024) DEFAULT NULL,
  `img` varchar(256) NOT NULL,
  `create_at` int(11) DEFAULT NULL,
  `update_at` int(11) DEFAULT NULL,
  `status` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `reply` varchar(512) NOT NULL,
  `reply_at` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `sales`;
CREATE TABLE `sales` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `store_id` int(11) unsigned NOT NULL DEFAULT '0',
  `name` varchar(32) NOT NULL,
  `description` varchar(512) DEFAULT NULL,
  `type` tinyint(4) unsigned NOT NULL DEFAULT '1',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `order` tinyint(4) unsigned NOT NULL DEFAULT '1',
  `start_at` int(11) unsigned NOT NULL DEFAULT '0',
  `end_at` int(11) unsigned NOT NULL DEFAULT '0',
  `created_at` int(11) unsigned NOT NULL DEFAULT '0',
  `updated_at` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `store_id` (`store_id`) USING BTREE,
  KEY `status` (`status`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `sales_options`;
CREATE TABLE `sales_options` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sales_id` int(11) unsigned NOT NULL DEFAULT '0',
  `lower` int(11) unsigned NOT NULL DEFAULT '0',
  `upper` int(11) unsigned NOT NULL DEFAULT '0',
  `promotion` decimal(8,2) unsigned NOT NULL DEFAULT '1.00',
  `currency` varchar(32) NOT NULL DEFAULT '1',
  `created_at` int(11) NOT NULL DEFAULT '0',
  `updated_at` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `sales_id` (`sales_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `ship_info`;
CREATE TABLE `ship_info` (
  `ship_id` int(11) NOT NULL AUTO_INCREMENT,
  `author` int(11) DEFAULT NULL COMMENT 'owner',
  `receiver` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `phone_num` char(32) COLLATE utf8_unicode_ci NOT NULL,
  `district` varchar(128) CHARACTER SET utf8 COLLATE utf8_slovenian_ci DEFAULT NULL,
  `address` varchar(2048) COLLATE utf8_unicode_ci NOT NULL COMMENT '详细地址',
  `default` tinyint(2) NOT NULL DEFAULT '0' COMMENT '0/1',
  `last_update` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `idcard` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `fullname` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `idimg1` varchar(200) COLLATE utf8_unicode_ci NOT NULL COMMENT 'id card',
  `idimg2` varchar(200) COLLATE utf8_unicode_ci NOT NULL COMMENT 'id card',
  PRIMARY KEY (`ship_id`)
) ENGINE=InnoDB AUTO_INCREMENT=617 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS  `shipping`;
CREATE TABLE `shipping` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '运送方式ID',
  `store_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '店铺ID',
  `type` tinyint(4) unsigned NOT NULL DEFAULT '2' COMMENT '快递方式，默认转运',
  `country` varchar(24) NOT NULL DEFAULT 'USA' COMMENT '发货国家',
  `currency` varchar(24) NOT NULL DEFAULT 'USD' COMMENT '货币',
  `low` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '消费最低值',
  `high` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '消费上限',
  `base_fee` decimal(5,2) unsigned NOT NULL DEFAULT '0.00',
  `low_fee` decimal(5,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '最低运费',
  `middleman` decimal(5,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '水客，按所在国货币',
  `status` tinyint(4) unsigned NOT NULL DEFAULT '1' COMMENT '状态',
  `create_at` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `days` varchar(24) NOT NULL DEFAULT '20-30' COMMENT '运输时长，天',
  `count_type` tinyint(4) unsigned NOT NULL DEFAULT '1' COMMENT '计量方式',
  `count_unit` varchar(32) NOT NULL DEFAULT 'YUAN' COMMENT '计量单位',
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `type` (`type`),
  KEY `store_id` (`store_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=515 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `size`;
CREATE TABLE `size` (
  `size_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(4096) COLLATE utf8_unicode_ci NOT NULL,
  `order` smallint(4) DEFAULT '0',
  `cat_id` int(11) NOT NULL,
  PRIMARY KEY (`size_id`),
  KEY `name` (`name`(255))
) ENGINE=InnoDB AUTO_INCREMENT=48473 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS  `size_chart`;
CREATE TABLE `size_chart` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `category` varchar(64) CHARACTER SET utf8mb4 DEFAULT NULL COMMENT '分类名称',
  `brand` varchar(64) CHARACTER SET utf8mb4 DEFAULT NULL COMMENT '品牌名称',
  `url` varchar(255) CHARACTER SET utf8mb4 NOT NULL COMMENT '图片地址',
  `create_at` int(11) unsigned NOT NULL COMMENT '创建时间',
  `userid` int(11) unsigned DEFAULT NULL,
  `is_default` tinyint(1) unsigned DEFAULT '0' COMMENT '是否默认',
  PRIMARY KEY (`id`),
  UNIQUE KEY `category_brand` (`category`,`brand`) USING BTREE,
  KEY `category` (`category`),
  KEY `brand` (`brand`)
) ENGINE=InnoDB AUTO_INCREMENT=495 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `spiders_work`;
CREATE TABLE `spiders_work` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'shopstyle',
  `name` varchar(64) NOT NULL COMMENT '最后一层分类名称',
  `products_sum` int(11) unsigned DEFAULT '0',
  `first` varchar(32) NOT NULL COMMENT '第一层分类',
  `second` varchar(32) NOT NULL COMMENT '第二层分类',
  `third` varchar(32) DEFAULT NULL COMMENT '第三层',
  `fourth` varchar(64) DEFAULT NULL COMMENT '第四层',
  `fifth` varchar(64) DEFAULT NULL COMMENT '第五层',
  `last_time` int(11) unsigned DEFAULT '0',
  `latest_time` int(11) unsigned NOT NULL DEFAULT '0',
  `d_value` int(11) unsigned DEFAULT '0',
  `times` int(11) unsigned NOT NULL DEFAULT '0',
  `info` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`) USING BTREE,
  KEY `products_sum` (`products_sum`)
) ENGINE=InnoDB AUTO_INCREMENT=99729 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `statistics`;
CREATE TABLE `statistics` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `users` int(11) unsigned DEFAULT '0',
  `orders` int(11) unsigned DEFAULT NULL,
  `sales` int(11) unsigned DEFAULT NULL,
  `active` int(11) unsigned DEFAULT NULL,
  `date` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `store`;
CREATE TABLE `store` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `show_name` varchar(64) DEFAULT NULL,
  `rebate` decimal(3,2) unsigned DEFAULT '0.95' COMMENT '返利比例',
  `url` varchar(64) DEFAULT NULL,
  `country` varchar(32) DEFAULT 'USA',
  `currency` varchar(24) DEFAULT 'USD',
  `direct_mail` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '快递直邮',
  `direct_mail_rate` decimal(4,3) unsigned NOT NULL DEFAULT '0.000' COMMENT '快递直邮 货价税率',
  `number_one` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '一号仓',
  `create_at` int(11) unsigned DEFAULT NULL,
  `update_at` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=335 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `superscript`;
CREATE TABLE `superscript` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `type` tinyint(4) unsigned NOT NULL DEFAULT '1',
  `size` varchar(32) NOT NULL DEFAULT '2x',
  `url` varchar(256) DEFAULT NULL,
  `status` tinyint(4) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `type` (`type`),
  KEY `size` (`size`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `tags`;
CREATE TABLE `tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(4096) COLLATE utf8_unicode_ci NOT NULL,
  `order` smallint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS  `upv`;
CREATE TABLE `upv` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uv` int(11) unsigned DEFAULT '0',
  `pv` int(11) unsigned DEFAULT '0',
  `timestamp` int(11) unsigned DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `timestamp` (`timestamp`)
) ENGINE=InnoDB AUTO_INCREMENT=609 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `user`;
CREATE TABLE `user` (
  `userid` int(10) NOT NULL AUTO_INCREMENT,
  `username` char(128) COLLATE utf8_unicode_ci NOT NULL COMMENT 'username',
  `password` char(64) COLLATE utf8_unicode_ci NOT NULL COMMENT 'password',
  `usertype` smallint(4) NOT NULL DEFAULT '0' COMMENT '0:普通用户，2：设计师 9管理员',
  `regtime` datetime NOT NULL COMMENT 'regtime',
  `lastlogin` datetime DEFAULT NULL COMMENT 'lastlogin',
  `bp_lastlogin` datetime DEFAULT NULL,
  `lastlogout` datetime DEFAULT NULL COMMENT 'lastlogout',
  `lastping` datetime DEFAULT NULL,
  `last_DeviceInfo` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `device` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isblocked` int(4) DEFAULT '0',
  `status` int(4) DEFAULT NULL COMMENT '0:fd不在线1:fd在线',
  `user_ip` char(16) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '用户注册ip,用于追踪来源',
  `recommend_username` char(32) COLLATE utf8_unicode_ci DEFAULT '0' COMMENT '推荐人',
  `cover` varchar(2048) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '背景图片',
  `from` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '来源',
  `self_status` int(11) DEFAULT '1' COMMENT '用户自己设置的在线状态,默认为在线,会与status共同起作用,暂时只作用于老师, 0:老师设置为完全隐身，1:老师i 设置为在线，5:只对试讲学生可见；6:只对付费学生可见；7:只对VIP用户可见',
  `multi` tinyint(4) DEFAULT '0' COMMENT '是否是特殊的老师，可以支持多个帐户共用',
  `oid` int(11) DEFAULT NULL COMMENT '用户最后一次登录设备类型（合作商）',
  `uuid` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '最后一次登录的用户的设备id号，客户端生成',
  `charge_card_buying_ratio` int(11) DEFAULT '0' COMMENT '该帐号购买充值卡的折扣率等级，0表示不能购买充值卡，>0 表示折扣比率（百分率）',
  `oauth_token` varchar(48) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '第三方合作TOKEN',
  `oauth_userid` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '第三方合作用户名/id',
  `oauth_source` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '来源站点标识',
  `is_allow_fudao` tinyint(1) DEFAULT '1' COMMENT '1 : allow fudao',
  `type` tinyint(4) DEFAULT '0' COMMENT '0 : 普通  1：咨询',
  `belong` varchar(32) COLLATE utf8_unicode_ci DEFAULT 'aifudao' COMMENT '学生或者老师所属于的所有者，默认为空，即aifudao，万利达为malata，如果代理商有专用帐号，应该在这里设置。',
  `foid` int(11) DEFAULT NULL COMMENT '合作厂商id（硬件厂商）',
  `fuuid` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '第一次登录的uuid，可以认为就是注册用户来源uuid',
  `membership` int(11) DEFAULT '2' COMMENT '会员类型，0:普通会员，1:付费学生会员；2:付费VIP老师会员 （SCIChat专用字段）',
  `gender` tinyint(2) DEFAULT '0',
  `name` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '姓名',
  `city` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `age` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nickname` varchar(128) COLLATE utf8_unicode_ci NOT NULL COMMENT '昵称',
  `introduce` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `level` smallint(4) DEFAULT NULL,
  `facepic` varchar(256) COLLATE utf8_unicode_ci DEFAULT 'http://product-album.img-cn-hangzhou.aliyuncs.com/avatar/default_avatar.png',
  `follower_num` int(11) DEFAULT NULL,
  `following_num` int(11) DEFAULT NULL,
  `ry_token` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ry_token_expire` int(11) DEFAULT '0',
  `description` text COLLATE utf8_unicode_ci,
  `rank` int(11) DEFAULT NULL,
  `rank_fans` int(11) DEFAULT '0',
  `rank_presold` int(11) DEFAULT '0',
  `boost` smallint(4) DEFAULT '0',
  `istop` int(10) unsigned DEFAULT '0',
  `chinese_name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `brand_type` tinyint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`userid`),
  UNIQUE KEY `username` (`username`),
  KEY `recommend_username` (`recommend_username`),
  KEY `usertype` (`usertype`),
  KEY `regtime` (`regtime`),
  KEY `isblocked` (`isblocked`)
) ENGINE=InnoDB AUTO_INCREMENT=448362 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='user info table';

DROP TABLE IF EXISTS  `user_alipay`;
CREATE TABLE `user_alipay` (
  `user_id` int(10) unsigned NOT NULL COMMENT '用户ID',
  `alipay_num` varchar(100) NOT NULL COMMENT '支付宝账号',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态 0 无效 1有效',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `user_coupon`;
CREATE TABLE `user_coupon` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `coupon_id` int(11) NOT NULL,
  `coupon_code` varchar(32) NOT NULL,
  `salt` smallint(4) unsigned NOT NULL DEFAULT '1000',
  `deal_id` varchar(64) DEFAULT NULL,
  `created_at` int(11) unsigned NOT NULL,
  `used_at` int(11) DEFAULT NULL,
  `user_id` int(11) unsigned DEFAULT '0',
  `user_mobile` varchar(32) DEFAULT '0',
  `source` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '0领取1系统2人工',
  `get_at` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `coupon_id` (`coupon_id`),
  KEY `coupon_code` (`coupon_code`),
  KEY `salt` (`salt`)
) ENGINE=InnoDB AUTO_INCREMENT=1138 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `user_fo_user`;
CREATE TABLE `user_fo_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `follow_userid` int(11) NOT NULL COMMENT '被follow人',
  `fo_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`userid`,`follow_userid`)
) ENGINE=InnoDB AUTO_INCREMENT=20903 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS  `user_msg`;
CREATE TABLE `user_msg` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `msgid` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `create_at` int(11) NOT NULL,
  `read_at` int(11) DEFAULT NULL,
  `type` tinyint(4) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `msgid` (`msgid`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=17868 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS  `user_role`;
CREATE TABLE `user_role` (
  `userid` int(11) NOT NULL,
  `role` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`userid`),
  KEY `role` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS  `users`;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS  `withdraw_cash`;
CREATE TABLE `withdraw_cash` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL COMMENT '用户ID',
  `value` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '提现金额',
  `bank_name` varchar(64) NOT NULL COMMENT '银行名称',
  `card` varchar(32) NOT NULL COMMENT '卡号',
  `name` varchar(32) NOT NULL COMMENT '户名',
  `created_at` int(11) unsigned NOT NULL DEFAULT '0',
  `updated_at` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '0新申请，1已提现，2驳回',
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;

SET FOREIGN_KEY_CHECKS = 1;

/* TRIGGERS */;
DROP TRIGGER IF EXISTS `testref`;
DELIMITER $$
CREATE TRIGGER `testref` AFTER INSERT ON `activity` FOR EACH ROW BEGIN
        UPDATE ad SET sum=sum+1;
END
$$
DELIMITER ;

